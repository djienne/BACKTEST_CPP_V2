#!/bin/sh
make
./backtest_double_EMA_float.exe
./backtest_double_EMA_StochRSI_float.exe
