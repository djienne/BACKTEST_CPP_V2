Usage:
* install docker
* open terminal and run "docker-compose up"
* data will be downloaded in the folder `user_data/data/`
